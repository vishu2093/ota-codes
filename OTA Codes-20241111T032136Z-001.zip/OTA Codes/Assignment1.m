% mat=[1 2 3 4 5 6; 2 3 4 5 6 7; 3 4 5 6 7 8; 4 5 6 7 8 9; 5 6 7 8 9 10]
% 
% %Sum of every row
% for i=1:5
%     sum_row=0;
%     for j=1:6
%         sum_row=sum_row+mat(i, j);
%     end
%     fprintf("Sum of row %d: %d\n", i, sum_row);
% end
% 
% %Sum of every column
% for i=1:6
%     sum_column=0;
%     for j=1:5
%         sum_column=sum_column+mat(j, i);
%     end
%     fprintf("Sum of column %d: %d\n", i, sum_column);
% end
% 
% %Sum of all elements
% sum_mat=0;
% for i=1:5
%     for j=1:6
%         sum_mat=sum_mat+mat(i, j);
%     end
% end
% fprintf("Sum of matrix: %d\n", sum_mat);

%Calculate Factorial
function result = factorial(n)
    if n < 0 || floor(n) ~= n
        error('Input must be a non-negative integer.');
    end

    result = 1;

    for i = 1:n
        result = result * i;
    end
end

fact_result = factorial(6);
fprintf('The factorial of 6 is %d.\n', fact_result);

% %Calculate grade using switch case
% prompt = 'Enter marks to know grade: ';
% grade = input(prompt);
% switch true
%     case grade >= 80 && grade <= 100
%         fprintf('Your grade for %d marks is: A\n', grade);
%     case grade >= 60 && grade <= 79
%         fprintf('Your grade for %d marks is: B\n', grade);
%     case grade >= 40 && grade <= 59
%         fprintf('Your grade for %d marks is: C\n', grade);
%     case grade >= 0 && grade < 40
%         fprintf('Your grade for %d marks is: F\n', grade);
%     otherwise
%         fprintf('Invalid input. Marks should be between 0 and 100.\n');
% end
% 
% %Calculate power
% function [result1, result2] = pow(a, b)
%     result1 = a^b;
% 
%     result2 = b^a;
% end
% [result1, result2] = pow(4, 6);
% fprintf('result1 (a^b) = %f\n', result1);
% fprintf('result2 (b^a) = %f\n', result2);