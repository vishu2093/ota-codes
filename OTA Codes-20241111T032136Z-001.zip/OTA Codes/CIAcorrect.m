% clc;
% clear;

function best_fitness_history = simple_cohort_intelligence(minMax, MaxIter, fitnessFunction, D, Npop, LB, UB)
    % Initialize the cohort members within the problem bounds
    population = zeros(Npop, D);
    for i = 1:Npop
        for j = 1:D
            population(i, j) = LB(j) + rand() * (UB(j) - LB(j));
        end
    end

    % Initialize best fitness and best position
    if strcmp(minMax, 'min')
        best_fitness = inf;
    else
        best_fitness = -inf;
    end
    best_position = zeros(1, D);
    best_fitness_history = zeros(MaxIter, 1);
    
    % Main iteration loop
    for iteration = 1:MaxIter
        fitness_values = zeros(Npop, 1);
        
        % Calculate fitness for each member in the population
        for i = 1:Npop
            fitness_values(i) = fitnessFunction(population(i, :));
        end
        
        % Update the best fitness
        if strcmp(minMax, 'min')
            [current_best_fitness, idx] = min(fitness_values);
            if current_best_fitness < best_fitness
                best_fitness = current_best_fitness;
                best_position = population(idx, :);
            end
        else
            [current_best_fitness, idx] = max(fitness_values);
            if current_best_fitness > best_fitness
                best_fitness = current_best_fitness;
                best_position = population(idx, :);
            end
        end
        
        % Record the best fitness of the iteration
        best_fitness_history(iteration) = best_fitness;

        % Update population members
        for i = 1:Npop
            for j = 1:D
                r = rand();
                population(i, j) = population(i, j) + r * (best_position(j) - population(i, j));
                population(i, j) = max(population(i, j), LB(j));
                population(i, j) = min(population(i, j), UB(j));
            end
        end
        
        % Print the iteration number and current best fitness
        %fprintf('Iteration %d: Best Fitness = %f\n', iteration, best_fitness);
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Single run main
clc;
clear;

% Parameters
Npop = 30;            % Population size
D = 5;                % Dimension of the problem
MaxIter = 200;        % Number of iterations
LB = -10 * ones(1, D); % Lower bounds for each dimension
UB = 10 * ones(1, D);  % Upper bounds for each dimension

% Run the Cohort Intelligence Algorithm for one iteration
iterwise_best = simple_cohort_intelligence('min', MaxIter, @fitnessFunction, D, Npop, LB, UB);

% Display the best fitness value found during the iteration
fprintf("Best value of fitness for the function after %d iterations is: %f\n", MaxIter, iterwise_best(end));

% Plot the convergence of best fitness value over iterations
figure;
plot(1:MaxIter, iterwise_best, 'LineWidth', 2);
xlabel('Iteration');
ylabel('Best Fitness');
title('Cohort Intelligence Algorithm Convergence');
grid on;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%20 runs main

% clc;
% clear;
% 
% % Define parameters
% MaxIter = 100; 
% D = 5; 
% Npop = 50; 
% n = 20; % Number of runs
% LB = -10 * ones(1, D); 
% UB = 10 * ones(1, D); 
% 
% % Initialize a matrix to store best fitness history for each run
% CI_bestFitness = zeros(MaxIter, n);
% CI_meanFitness = zeros(MaxIter, 1);
% 
% % Run the Cohort Intelligence optimization n times
% for run = 1:n
%     fprintf("Beginning run %d.\n", run);
%     [bestFitnessOverTime] = simple_cohort_intelligence('min', MaxIter, @fitnessFunction, D, Npop, LB, UB);
%     CI_bestFitness(:, run) = bestFitnessOverTime;
% end
% 
% % Calculate mean and standard deviation of fitness across all runs
% CI_meanFitness = mean(CI_bestFitness, 2);
% CI_stddevFitness = std(CI_bestFitness, 0, 2);
% 
% % Plot mean fitness over iterations
% figure;
% plot(1:MaxIter, CI_meanFitness, 'b', 'LineWidth', 2);
% xlabel('Iteration');
% ylabel('Mean Fitness Value');
% title('Mean Fitness Value Over Iterations for Cohort Intelligence');
% legend('Cohort Intelligence');
% grid on;
% 
% % Plot best fitness value over iterations
% figure;
% plot(1:MaxIter, min(CI_bestFitness, [], 2), 'r', 'LineWidth', 2);
% xlabel('Iteration');
% ylabel('Best Fitness Value');
% title('Best Fitness Value Over Iterations for Cohort Intelligence');
% legend('Cohort Intelligence');
% grid on;
% 
% % Display final results
% disp('Best value from all runs:');
% disp(min(CI_bestFitness(end, :)));
% 
% disp('Last iteration average value:');
% disp(CI_meanFitness(end));
% 
% disp('Standard deviation of last iteration values across all runs:');
% disp(CI_stddevFitness(end));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



function fitness_val = fitnessFunction(x)
    D = numel(x);  
    sum_square = sum(x.^2); 
    sum_cos = sum(cos(2 * pi * x));  
    fitness_val = -20 * exp(-0.2 * sqrt(sum_square / D)) - exp(sum_cos / D) + 20 + exp(1);  
end
