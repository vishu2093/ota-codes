% % Question 1
% x1 = linspace(0, 5);
% y1 = (20 - 8*x1) / 5;
% x2 = linspace(0, 5);
% y2 = (20 - 5*x2) / 8;
% hold on;
% plot(x1, y1, 'r', 'DisplayName', '8x + 5y = 20');
% plot(x2, y2, 'b', 'DisplayName', '5x + 8y = 20');
% x = linspace(-1, 5);
% y = linspace(0, 0);
% plot(x, y, 'k');
% plot(y, x, 'k');
% xlabel('x');
% ylabel('y');
% axis([0 5 0 5]);
% plot(0, 0, 'go', 'DisplayName', '(0,0)');
% plot(2.5, 0, 'go', 'DisplayName', '(2.5,0)');
% plot(0, 2.5, 'go', 'DisplayName', '(0,2.5)');
% plot(20/13, 20/13, 'go', 'DisplayName', '(20/13,20/13)');
% legend show;
% hold off;
% 
% function z = func1(x, y)
%     z = 5*x + 10*y;
% end
% val_1 = func1(0, 0);      
% val_2 = func1(2.5, 0);     
% val_3 = func1(0, 2.5);      
% val_4 = func1(20/13, 20/13); 
% 
% values = [val_1, val_2, val_3, val_4];
% 
% [maxValue, maxIndex] = max(values);
% [minValue, minIndex] = min(values);
% 
% disp(['The maximum value is ', num2str(maxValue), ' at index ', num2str(maxIndex)]);
% disp(['The minimum value is ', num2str(minValue), ' at index ', num2str(minIndex)]);

% % Question 2
% x1 = linspace(0, 150);
% y1 = 300 - 2*x1; 
% 
% x2 = linspace(0, 170);
% y2 = (509 - 3*x2) / 4; 
% 
% x3 = linspace(0, 203);
% y3 = (812 - 4*x3) / 7; 
% 
% hold on;
% plot(x1, y1, 'r', 'DisplayName', '2x + y = 300');
% plot(x2, y2, 'b', 'DisplayName', '3x + 4y = 509');
% plot(x3, y3, 'g', 'DisplayName', '4x + 7y = 812');
% 
% x = linspace(-10, 200);
% y = linspace(0, 0);
% plot(x, y, 'k');
% plot(y, x, 'k');
% xlabel('x');
% ylabel('y');
% axis([0 205 0 300]);
% 
% plot(0, 812/7, 'go', 'DisplayName', '(0, 812/7)');
% plot(150, 0, 'go', 'DisplayName', '(150,0)');
% plot(691/5, 118/5, 'go', 'DisplayName', '(691/5, 118/5)');
% plot(63, 80, 'go', 'DisplayName', '(63, 80)');
% plot(0, 0, 'go', 'DisplayName', '(0, 0)');
% 
% legend show;
% hold off;
% 
% function z = func2(x, y)
%     z = 50*x + 60*y;
% end
% 
% val_1 = func2(0, 812/7);      
% val_2 = func2(150, 0);      
% val_3 = func2(691/5, 118/5);     
% val_4 = func2(63, 80);   
% val_5 = func2(0, 0);
% 
% values = [val_1, val_2, val_3, val_4, val_5];
% 
% [maxValue, maxIndex] = max(values);
% [minValue, minIndex] = min(values);
% 
% disp(['The maximum value is ', num2str(maxValue), ' at index ', num2str(maxIndex)]);
% disp(['The minimum value is ', num2str(minValue), ' at index ', num2str(minIndex)]);

% % Question 3
% x1 = linspace(0, 20);
% y1 = 20 - x1; 
% 
% x2 = linspace(0, 24);
% y2 = (72 - 3*x2) / 4; 
% 
% hold on;
% plot(x1, y1, 'r', 'DisplayName', 'x + y = 20');
% plot(x2, y2, 'b', 'DisplayName', '3x + 4y = 72');
% 
% x = linspace(-5, 25);
% y = linspace(0, 0);
% plot(x, y, 'k');
% plot(y, x, 'k');
% 
% xlabel('x');
% ylabel('y');
% axis([0 25 0 25]);
% 
% plot(0, 18, 'go', 'DisplayName', '(0,18)');
% plot(20, 0, 'go', 'DisplayName', '(20,0)');
% plot(0, 0, 'go', 'DisplayName', '(0,0)');
% plot(8, 12, 'go', 'DisplayName', '(8,12)');
% legend show;
% hold off;
% 
% function z = func(x, y)
%     z = 4*x + 5*y;
% end
% 
% val_1 = func(0, 18);         
% val_2 = func(20, 0);        
% val_3 = func(0, 0); 
% val_4 = func(8, 12);
% 
% values = [val_1, val_2, val_3, val_4];
% 
% [maxValue, maxIndex] = max(values);
% [minValue, minIndex] = min(values);
% 
% disp(['The maximum value is ', num2str(maxValue), ' at index ', num2str(maxIndex)]);
% disp(['The minimum value is ', num2str(minValue), ' at index ', num2str(minIndex)]);

% Question 4
x1 = linspace(0, 200);
y1 = (1000 - 5*x1) / 2; 

x2 = linspace(0, 300);
y2 = (900 - 3*x2) / 2; 

x3 = linspace(0, 250);
y3 = (500 - x3) / 2; 

hold on;
plot(x1, y1, 'r', 'DisplayName', '5x + 2y = 1000');
plot(x2, y2, 'b', 'DisplayName', '3x + 2y = 900');
plot(x3, y3, 'g', 'DisplayName', 'x + 2y = 500');

xlabel('x');
ylabel('y');
axis([0 300 0 500]);


A = [5 2; 1 2];
b = [1000; 500];
intersection2 = A\b;


plot(intersection2(1), intersection2(2), 'go', 'DisplayName', sprintf('(%0.2f,%0.2f)', intersection2(1), intersection2(2)));
plot(0, 250, 'go', 'DisplayName', '(0,250)');
plot(200, 0, 'go', 'DisplayName', '(200,0)');
plot(0, 0, 'go', 'DisplayName', '(0,0)');

legend show;
hold off;

function z = func(x, y)
    z = 100*x + 40*y;
end
 
val_2 = func(intersection2(1), intersection2(2)); 
val_4 = func(0, 0); 
val_5 = func(200, 0); 
val_6 = func(0, 250); 

values = [val_2, val_4, val_5, val_6];

[maxValue, maxIndex] = max(values);
[minValue, minIndex] = min(values);

disp(['The maximum value is ', num2str(maxValue), ' at index ', num2str(maxIndex)]);
disp(['The minimum value is ', num2str(minValue), ' at index ', num2str(minIndex)]);
