% function A = garden_area(W)
%     if W < 0 || W > 100
%         error('Width W must be greater than 0 and less than 100.');
%     end
%     L = 100 - 2*W;
%     A = L * W;
%     fprintf('For width W = %.2f, Length L = %.2f\n Area = %.2f\n', W, L, A);
% end

% function V = box_volume(x)
%     if x < 0 || x > 12
%         error('Side length x must be between 0 and 12.');
%     end
%     V = x * (24 - 2*x) * (36 - 2*x);
%     fprintf('For square cut side x = %.2f, Volume = %.2f\n', x, V);
% end
% function T = travel_time(x)
%     if x < 0 || x > 66
%         error('Distance run x must be between 0 and 66.');
%     end
%     T = (x / 88) + (sqrt((66 - x)^2 + 22^2) / 33);
%     fprintf('For distance run x = %.2f, Time = %.2f hours\n', x, T);
% end
% function R = rental_revenue(p)
%     if p < 50 || p > 200
%         error('Price p must be between 50 and 200.');
%     end
%     R = p * (1000 - 5*p);
%     fprintf('For price p = %.2f, Revenue = %.2f\n', p, R);
% end
function A = rectangle_area(x)
    if x < 0 || x > 2*sqrt(2)
        error('Value x must be between 0 and 2*sqrt(2).');
    end
    y = sqrt(1 - (x^2 / 4));
    A = 4 * x * y;
    fprintf('For x = %.2f, y = %.2f, Area = %.2f\n', x, y, A);
end


% % Problem 1: Rectangular Garden
% W = 30;
% area1 = garden_area(W);

% % Problem 2: Open-Top Box
% x = 2;
% volume = box_volume(x);

% % Problem 3: Minimize Travel Time
% x = 35; 
% time = travel_time(x);

% % Problem 4: Maximize Revenue for Car Rental
% p = 90; 
% revenue = rental_revenue(p);
% 
% Problem 5: Rectangle Inscribed in Ellipse
x = 1.5; 
area = rectangle_area(x);